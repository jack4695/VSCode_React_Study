import { createContext } from "react";

//함수를 통해 컨텍스트 생성. 초기값은 문자열 데이터로 설정
export const SimpleContext = createContext("Hello SimpleContext 123");