import CompContext2b from "./CompContext2b";


const CompContext1b = () => {
  return (
    <div>
      <h4>Context1b 컴포넌트</h4>
      <CompContext2b />
    </div>
  );
}

export default CompContext1b;