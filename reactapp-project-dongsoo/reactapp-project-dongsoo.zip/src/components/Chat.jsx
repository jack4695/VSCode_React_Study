function Chat(props) {
  return (<>
    <h2>채팅방 입니다.</h2>
  </>); 
}
export default Chat; 