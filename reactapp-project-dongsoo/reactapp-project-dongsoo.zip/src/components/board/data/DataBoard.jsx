function DataBoard(props) {
  return (<>
    <h2>자료 게시판 - 사진 열람 등 가능해요
    </h2>
  </>); 
}
export default DataBoard; 