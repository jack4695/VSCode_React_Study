import MainIntro from "./MainIntro";

const Home = () => {
  

    return (<>
    <MainIntro />
    </>);
  }

  export default Home;